package site.lashop.lashopbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaShopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
